# Grafana - Visualization and Monitoring Platform

## Overview

Grafana is an open-source visualization and monitoring platform that enables you to query, visualize, alert on, and understand your metrics no matter where they are stored. It provides beautiful dashboards and graphs with a powerful query editor that supports multiple data sources.

### Key Features
- **Multi-Source Support**: Connect to Prometheus, InfluxDB, Elasticsearch, MySQL, PostgreSQL, and many more
- **Beautiful Dashboards**: Create dynamic and interactive dashboards
- **Alerting**: Built-in alerting with multiple notification channels
- **Templating**: Use variables to create dynamic and reusable dashboards
- **Annotations**: Mark events on graphs to correlate with metrics
- **Plugin System**: Extensible with custom plugins and data sources
- **Enterprise Features**: Team management, SSO, and audit logging in Grafana Enterprise

## Core Concepts

### Grafana Architecture
- **Grafana Server**: Main application that serves the web interface and API
- **Data Sources**: Connections to databases and metric stores
- **Dashboards**: Collections of panels that visualize data
- **Panels**: Individual visualizations within dashboards
- **Queries**: Requests to data sources for data
- **Alerting**: Rule-based notifications for metric thresholds
- **Users**: Authentication and authorization system

### Key Components
- **Data Sources**: Connections to time series databases, SQL databases, and other data stores
- **Dashboards**: Collections of panels organized in rows
- **Panels**: Individual visualizations (graphs, tables, gauges, etc.)
- **Queries**: Expressions that retrieve data from sources
- **Variables**: Template variables that make dashboards dynamic
- **Annotations**: Events marked on graphs
- **Alert Rules**: Conditions that trigger notifications
- **Notification Channels**: Destinations for alert notifications

### Visualization Types
- **Graph**: Line, area, and bar charts
- **Stat**: Single large numeric display
- **Gauge**: Circular gauge visualization
- **Table**: Tabular data display
- **Heatmap**: Color-coded matrix visualization
- **Pie Chart**: Proportional data visualization
- **Logs**: Log display and search
- **Trace**: Distributed tracing visualization
- **Node Graph**: Network topology visualization

## Installation & Setup

### Prerequisites
- **Operating System**: Linux, macOS, Windows
- **Memory**: Minimum 512MB RAM (1GB recommended)
- **Disk**: Minimum 200MB free space
- **Network**: Port 3000 for web interface (default)

### Installation Methods

#### Using Package Manager (Ubuntu/Debian)
```bash
# Add Grafana GPG key
sudo apt-get install -y apt-transport-https
sudo apt-get install -y software-properties-common wget
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -

# Add Grafana repository
echo "deb https://packages.grafana.com/oss/deb stable main" | sudo tee -a /etc/apt/sources.list.d/grafana.list

# Update package list
sudo apt-get update

# Install Grafana
sudo apt-get install grafana

# Start Grafana service
sudo systemctl start grafana-server
sudo systemctl enable grafana-server

# Verify installation
sudo systemctl status grafana-server
```

#### Using Package Manager (CentOS/RHEL)
```bash
# Add Grafana repository
sudo yum install -y https://dl.grafana.com/enterprise/release/grafana-enterprise-9.3.6-1.x86_64.rpm

# Install Grafana
sudo yum install grafana-enterprise

# Start Grafana service
sudo systemctl start grafana-server
sudo systemctl enable grafana-server

# Verify installation
sudo systemctl status grafana-server
```

#### Using Docker
```bash
# Run Grafana in Docker
docker run -d \
  --name=grafana \
  -p 3000:3000 \
  grafana/grafana-enterprise:9.3.6

# Run with persistent volume
docker run -d \
  --name=grafana \
  -p 3000:3000 \
  -v grafana-storage:/var/lib/grafana \
  grafana/grafana-enterprise:9.3.6

# Run with custom configuration
docker run -d \
  --name=grafana \
  -p 3000:3000 \
  -v /path/to/grafana.ini:/etc/grafana/grafana.ini \
  -v grafana-storage:/var/lib/grafana \
  grafana/grafana-enterprise:9.3.6
```

#### Using Helm (Kubernetes)
```bash
# Add Grafana Helm repository
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

# Install Grafana
helm install grafana grafana/grafana

# Install with custom values
helm install grafana grafana/grafana -f values.yaml
```

## Grafana Configuration

### Configuration File (grafana.ini)
```ini
# /etc/grafana/grafana.ini

[server]
# Protocol (http, https, socket)
protocol = http

# The ip address to bind to
http_addr =

# The http port to use
http_port = 3000

# The public facing domain name
domain = localhost

# Redirect to correct domain if host header does not match domain
enforce_domain = false

[database]
# Either "mysql", "postgres" or "sqlite3"
type = sqlite3

# Database host
host = 127.0.0.1:3306

# Database name
name = grafana

# Database user
user = grafana

# Database password
password =

[security]
# Default admin user
admin_user = admin

# Default admin password
admin_password = admin

# Secret key for signing
secret_key = SW2YcwTIb9zpOOhoPsMm

[users]
# Disable user signup / registration
allow_sign_up = false

# Allow non admin users to create organizations
allow_org_create = false

# Set to true to automatically assign new users to the default organization
auto_assign_org = true

[auth]
# Set to true to enable login form
login_form = true

[auth.anonymous]
# Enable anonymous access
enabled = false

[auth.basic]
# Enable basic auth
enabled = true

[auth.proxy]
# Enable proxy auth
enabled = false

[smtp]
# Enable SMTP
enabled = false

# SMTP server host
host = localhost:25

# SMTP user
user =

# SMTP password
password =

[emails]
# Welcome email on signup
welcome_email_on_sign_up = false

[log]
# Log format (console, file, syslog)
mode = console

# Log level (trace, debug, info, warn, error, critical)
level = info

[log.console]
# Console log format
format = console

[log.file]
# File log path
path = /var/log/grafana/grafana.log

[log.syslog]
# Syslog facility
facility = local5

[dataproxy]
# Logging level
logging = info

[tracing.jaeger]
# Enable Jaeger tracing
enabled = false

[metrics]
# Enable metrics
enabled = false

[metrics.graphite]
# Graphite metrics
enabled = false

[alerting]
# Enable alerting
enabled = true

# Execute alerts
execute_alerts = true

[unified_alerting]
# Enable unified alerting
enabled = true
```

### Environment Variables
```bash
# Common environment variables
GF_SECURITY_ADMIN_USER=admin
GF_SECURITY_ADMIN_PASSWORD=admin
GF_USERS_ALLOW_SIGN_UP=false
GF_INSTALL_PLUGINS=grafana-clock-panel,grafana-simple-json-datasource
GF_SMTP_ENABLED=true
GF_SMTP_HOST=smtp.gmail.com:587
GF_SMTP_USER=your-email@gmail.com
GF_SMTP_PASSWORD=your-password
GF_SMTP_FROM_ADDRESS=your-email@gmail.com
```

## Data Sources

### Adding Data Sources

#### Prometheus Data Source
```yaml
# Via UI
1. Go to Configuration → Data Sources
2. Click "Add data source"
3. Select "Prometheus"
4. Configure:
   - URL: http://prometheus:9090
   - Access: Server (default)
   - Scrape interval: 15s
   - Query timeout: 60s
5. Click "Save & Test"
```

#### InfluxDB Data Source
```yaml
# Via UI
1. Go to Configuration → Data Sources
2. Click "Add data source"
3. Select "InfluxDB"
4. Configure:
   - URL: http://influxdb:8086
   - Database: mydb
   - User: myuser
   - Password: mypassword
   - HTTP Method: POST
5. Click "Save & Test"
```

#### Elasticsearch Data Source
```yaml
# Via UI
1. Go to Configuration → Data Sources
2. Click "Add data source"
3. Select "Elasticsearch"
4. Configure:
   - URL: http://elasticsearch:9200
   - Index: [index-pattern-]YYYY.MM.DD
   - Time field: @timestamp
   - Version: 7.0+
5. Click "Save & Test"
```

#### MySQL Data Source
```yaml
# Via UI
1. Go to Configuration → Data Sources
2. Click "Add data source"
3. Select "MySQL"
4. Configure:
   - Host: mysql:3306
   - Database: mydb
   - User: myuser
   - Password: mypassword
   - Max idle conn: 100
   - Max open conn: 100
5. Click "Save & Test"
```

### Data Source Configuration via API
```bash
# Create Prometheus data source
curl -X POST -H "Content-Type: application/json" \
  -d '{
    "name":"Prometheus",
    "type":"prometheus",
    "url":"http://prometheus:9090",
    "access":"proxy",
    "basicAuth":false
  }' \
  http://admin:admin@localhost:3000/api/datasources

# Create InfluxDB data source
curl -X POST -H "Content-Type: application/json" \
  -d '{
    "name":"InfluxDB",
    "type":"influxdb",
    "url":"http://influxdb:8086",
    "access":"proxy",
    "database":"mydb",
    "user":"myuser",
    "password":"mypassword",
    "basicAuth":false
  }' \
  http://admin:admin@localhost:3000/api/datasources
```

## Dashboards

### Creating Dashboards

#### Via UI
```bash
# Create new dashboard
1. Click "+" icon in left sidebar
2. Select "New dashboard"
3. Add panels by clicking "Add panel"
4. Configure each panel with queries and visualization options
5. Save dashboard with name and folder
```

#### Via Configuration (Dashboard JSON)
```json
{
  "annotations": {
    "list": [
      {
        "builtIn": 1,
        "datasource": "-- Grafana --",
        "enable": true,
        "hide": true,
        "iconColor": "rgba(0, 211, 255, 1)",
        "name": "Annotations & Alerts",
        "type": "dashboard"
      }
    ]
  },
  "editable": true,
  "gnetId": null,
  "graphTooltip": 0,
  "id": 1,
  "links": [],
  "panels": [
    {
      "datasource": "Prometheus",
      "description": "",
      "fieldConfig": {
        "defaults": {
          "color": {
            "mode": "palette-classic"
          },
          "custom": {
            "axisCenteredZero": false,
            "axisColorMode": "text",
            "axisLabel": "",
            "axisPlacement": "auto",
            "barAlignment": 0,
            "drawStyle": "line",
            "fillOpacity": 0,
            "gradientMode": "none",
            "hideFrom": {
              "legend": false,
              "tooltip": false,
              "viz": false
            },
            "lineInterpolation": "linear",
            "lineWidth": 1,
            "pointSize": 5,
            "scaleDistribution": {
              "type": "linear"
            },
            "showPoints": "auto",
            "spanNulls": false,
            "stacking": {
              "group": "A",
              "mode": "none"
            },
            "thresholdsStyle": {
              "mode": "off"
            },
            "thresholds": {
              "steps": [
                {
                  "color": "green",
                  "value": null
                },
                {
                  "color": "red",
                  "value": 80
                }
              ]
            },
            "unit": "short"
          },
          "mappings": [],
          "thresholds": {
            "mode": "absolute",
            "steps": [
              {
                "color": "green",
                "value": null
              },
              {
                "color": "red",
                "value": 80
              }
            ]
          },
          "unit": "short"
        },
        "overrides": []
      },
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 0,
        "y": 0
      },
      "id": 2,
      "options": {
        "legend": {
          "calcs": [],
          "displayMode": "list",
          "placement": "bottom",
          "showLegend": true
        },
        "tooltip": {
          "mode": "single",
          "sort": "none"
        }
      },
      "targets": [
        {
          "datasource": "Prometheus",
          "expr": "rate(http_requests_total[5m])",
          "refId": "A"
        }
      ],
      "title": "HTTP Request Rate",
      "type": "timeseries"
    }
  ],
  "refresh": "5s",
  "schemaVersion": 36,
  "style": "dark",
  "tags": [],
  "templating": {
    "list": []
  },
  "time": {
    "from": "now-1h",
    "to": "now"
  },
  "timepicker": {},
  "timezone": "",
  "title": "New Dashboard",
  "uid": "new-dashboard",
  "version": 0,
  "weekStart": ""
}
```

### Importing Dashboards

#### Via UI
```bash
# Import dashboard
1. Go to Dashboards → Import
2. Enter dashboard ID or upload JSON file
3. Select data source for each panel
4. Click Import
```

#### Via API
```bash
# Import dashboard
curl -X POST -H "Content-Type: application/json" \
  -d '{
    "dashboard": {
      "id": null,
      "title": "Service Overview",
      "tags": ["templated"],
      "timezone": "browser",
      "panels": [...],
      "time": {
        "from": "now-6h",
        "to": "now"
      }
    },
    "overwrite": false,
    "message": "Imported from API"
  }' \
  http://admin:admin@localhost:3000/api/dashboards/import
```

## Panels and Visualizations

### Panel Types

#### Time Series Panel
```json
{
  "type": "timeseries",
  "title": "CPU Usage",
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "100 - (avg by (instance) (irate(node_cpu_seconds_total{mode=\"idle\"}[5m])) * 100)",
      "refId": "A"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "custom": {
        "drawStyle": "line",
        "lineInterpolation": "linear",
        "fillOpacity": 10,
        "stacking": "none"
      },
      "unit": "percent"
    }
  }
}
```

#### Stat Panel
```json
{
  "type": "stat",
  "title": "Current Memory Usage",
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100",
      "refId": "A"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "unit": "percent",
      "mappings": [],
      "thresholds": {
        "steps": [
          {
            "color": "green",
            "value": null
          },
          {
            "color": "yellow",
            "value": 70
          },
          {
            "color": "red",
            "value": 90
          }
        ]
      },
      "colorMode": "value"
    }
  }
}
```

#### Gauge Panel
```json
{
  "type": "gauge",
  "title": "Disk Usage",
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "(1 - (node_filesystem_avail_bytes{mountpoint=\"/\"} / node_filesystem_size_bytes{mountpoint=\"/\"})) * 100",
      "refId": "A"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "unit": "percent",
      "min": 0,
      "max": 100,
      "thresholds": {
        "steps": [
          {
            "color": "green",
            "value": null
          },
          {
            "color": "yellow",
            "value": 70
          },
          {
            "color": "red",
            "value": 90
          }
        ]
      }
    }
  }
}
```

#### Table Panel
```json
{
  "type": "table",
  "title": "Top Processes",
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "topk(5, rate(process_cpu_seconds_total[5m]))",
      "refId": "A"
    }
  ],
  "fieldConfig": {
    "defaults": {
      "custom": {
        "align": "auto",
        "filterable": true
      }
    }
  }
}
```

### Panel Configuration

#### Query Editor
```json
{
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "rate(http_requests_total{job=\"$job\", status=~\"$status\"}[5m])",
      "refId": "A",
      "legendFormat": "{{method}} {{status}}"
    }
  ]
}
```

#### Transformations
```json
{
  "transformations": [
    {
      "id": "calculateField",
      "options": {
        "mode": "binary",
        "reduce": {
          "reducer": "sum"
        }
      }
    },
    {
      "id": "filterByValue",
      "options": {
        "filters": [
          {
            "value": 0,
            "operator": ">"
          }
        ]
      }
    }
  ]
}
```

## Variables and Templating

### Variable Types

#### Query Variable
```json
{
  "name": "job",
  "type": "query",
  "query": "label_values(up, job)",
  "refresh": 1,
  "regex": "",
  "sort": 1,
  "tagValuesQuery": "",
  "useTags": false
}
```

#### Interval Variable
```json
{
  "name": "interval",
  "type": "interval",
  "query": "1m,10m,30m,1h,6h,12h,1d,7d,14d,30d",
  "current": {
    "selected": false,
    "text": "1m",
    "value": "1m"
  },
  "options": [
    {
      "selected": true,
      "text": "1m",
      "value": "1m"
    },
    {
      "selected": false,
      "text": "10m",
      "value": "10m"
    }
  ]
}
```

#### Constant Variable
```json
{
  "name": "environment",
  "type": "constant",
  "query": "production",
  "current": {
    "selected": false,
    "text": "production",
    "value": "production"
  },
  "options": [
    {
      "selected": true,
      "text": "production",
      "value": "production"
    }
  ]
}
```

#### Custom Variable
```json
{
  "name": "app",
  "type": "custom",
  "query": "web,api,db",
  "current": {
    "selected": false,
    "text": "web",
    "value": "web"
  },
  "options": [
    {
      "selected": true,
      "text": "web",
      "value": "web"
    },
    {
      "selected": false,
      "text": "api",
      "value": "api"
    },
    {
      "selected": false,
      "text": "db",
      "value": "db"
    }
  ]
}
```

### Using Variables in Queries
```promql
# Single variable
rate(http_requests_total{job="$job"}[5m])

# Multiple variables
rate(http_requests_total{job="$job", instance="$instance"}[5m])

# Variable in legend format
rate(http_requests_total{job="$job"}[5m])

# Variable in interval
rate(http_requests_total{job="$job"}[$interval])
```

## Alerting

### Alert Rules

#### Creating Alert Rules
```json
{
  "conditions": [
    {
      "evaluator": {
        "params": [
          80
        ],
        "type": "gt"
      },
      "operator": {
        "type": "and"
      },
      "query": {
        "params": [
          "A",
          "5m",
          "now"
        ]
      },
      "reducer": {
        "params": [],
        "type": "avg"
      },
      "type": "query"
    }
  ],
  "frequency": "60s",
  "for": "5m",
  "name": "High CPU Usage",
  "noDataState": "no_data",
  "notifications": [
    {
      "uid": "channel-1"
    }
  ],
  "settings": {
    "alertRuleType": "grafana"
  }
}
```

#### Alert Conditions
```json
{
  "conditions": [
    {
      "evaluator": {
        "params": [
          90
        ],
        "type": "gt"
      },
      "operator": {
        "type": "and"
      },
      "query": {
        "params": [
          "A",
          "5m",
          "now"
        ]
      },
      "reducer": {
        "params": [],
        "type": "avg"
      },
      "type": "query"
    }
  ]
}
```

### Notification Channels

#### Email Notification
```json
{
  "name": "Email",
  "type": "email",
  "settings": {
    "addresses": "admin@example.com",
    "singleEmail": true
  }
}
```

#### Slack Notification
```json
{
  "name": "Slack",
  "type": "slack",
  "settings": {
    "url": "https://hooks.slack.com/services/...",
    "channel": "#alerts",
    "username": "Grafana"
  }
}
```

#### Webhook Notification
```json
{
  "name": "Webhook",
  "type": "webhook",
  "settings": {
    "url": "http://localhost:8080/webhook",
    "httpMethod": "POST",
    "maxAlerts": 0
  }
}
```

## Plugins

### Panel Plugins

#### Clock Panel
```bash
# Install
grafana-cli plugins install grafana-clock-panel

# Configuration
{
  "type": "grafana-clock-panel",
  "title": "Current Time",
  "options": {
    "clockType": "digital",
    "timezone": "browser",
    "dateDisplay": "none"
  }
}
```

#### Pie Chart Panel
```bash
# Install
grafana-cli plugins install grafana-piechart-panel

# Configuration
{
  "type": "grafana-piechart-panel",
  "title": "HTTP Status Codes",
  "targets": [
    {
      "datasource": "Prometheus",
      "expr": "sum by (status) (rate(http_requests_total[5m]))",
      "refId": "A"
    }
  ]
}
```

### Data Source Plugins

#### Simple JSON Data Source
```bash
# Install
grafana-cli plugins install grafana-simple-json-datasource

# Configuration
{
  "name": "Simple JSON",
  "type": "grafana-simple-json-datasource",
  "url": "http://localhost:8080",
  "access": "proxy"
}
```

#### Elasticsearch Data Source
```bash
# Install
grafana-cli plugins install grafana-elasticsearch-datasource

# Configuration
{
  "name": "Elasticsearch",
  "type": "elasticsearch",
  "url": "http://elasticsearch:9200",
  "index": "metrics-*",
  "timeField": "@timestamp"
}
```

## Grafana API

### Authentication
```bash
# Using API key
curl -H "Authorization: Bearer eyJrIjoi...GciOiJIUzI1NiIsInR5cCI6IkFUTiJ9" \
  http://localhost:3000/api/dashboards

# Using basic auth
curl -u admin:admin http://localhost:3000/api/dashboards
```

### Dashboard API
```bash
# Search dashboards
curl http://admin:admin@localhost:3000/api/search?query=demo

# Get dashboard by UID
curl http://admin:admin@localhost:3000/api/dashboards/uid/demo-dashboard

# Create dashboard
curl -X POST -H "Content-Type: application/json" \
  -d '{"dashboard": {...}, "folderId": 0, "overwrite": false}' \
  http://admin:admin@localhost:3000/api/dashboards/db

# Update dashboard
curl -X PUT -H "Content-Type: application/json" \
  -d '{"dashboard": {...}, "overwrite": true}' \
  http://admin:admin@localhost:3000/api/dashboards/db/demo-dashboard
```

### Data Source API
```bash
# Get data sources
curl http://admin:admin@localhost:3000/api/datasources

# Get data source by ID
curl http://admin:admin@localhost:3000/api/datasources/1

# Create data source
curl -X POST -H "Content-Type: application/json" \
  -d '{"name": "Prometheus", "type": "prometheus", "url": "http://prometheus:9090", "access": "proxy"}' \
  http://admin:admin@localhost:3000/api/datasources

# Update data source
curl -X PUT -H "Content-Type: application/json" \
  -d '{"id": 1, "name": "Prometheus", "type": "prometheus", "url": "http://prometheus:9090", "access": "proxy"}' \
  http://admin:admin@localhost:3000/api/datasources/1
```

### User API
```bash
# Get users
curl http://admin:admin@localhost:3000/api/users

# Get current user
curl http://admin:admin@localhost:3000/api/user

# Create user
curl -X POST -H "Content-Type: application/json" \
  -d '{"name": "User", "email": "user@example.com", "login": "user", "password": "password"}' \
  http://admin:admin@localhost:3000/api/admin/users

# Update user
curl -X PUT -H "Content-Type: application/json" \
  -d '{"email": "newuser@example.com"}' \
  http://admin:admin@localhost:3000/api/users/2
```

## Grafana Provisioning

### Data Source Provisioning
```yaml
# /etc/grafana/provisioning/datasources/datasources.yml
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    orgId: 1
    url: http://prometheus.istio-system:9090
    basicAuth: false
    isDefault: true
    version: 1
    editable: true
    jsonData:
      httpMethod: POST
      queryTimeout: 60s
      timeInterval: 15s

  - name: InfluxDB
    type: influxdb
    access: proxy
    orgId: 1
    url: http://influxdb.istio-system:8086
    database: mydb
    user: myuser
    password: mypassword
    basicAuth: false
    isDefault: false
    version: 1
    editable: true
```

### Dashboard Provisioning
```yaml
# /etc/grafana/provisioning/dashboards/dashboards.yml
apiVersion: 1

providers:
  - name: 'default'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards/json
```

### Folder Provisioning
```yaml
# /etc/grafana/provisioning/folders/folders.yml
apiVersion: 1

folders:
  - name: General
    id: 1
    uid: general
  - name: Infrastructure
    id: 2
    uid: infrastructure
  - name: Applications
    id: 3
    uid: applications
```

## Grafana Enterprise Features

### Teams and Roles
```bash
# Create team
curl -X POST -H "Content-Type: application/json" \
  -d '{"name": "DevOps Team", "email": "devops@example.com"}' \
  http://admin:admin@localhost:3000/api/teams

# Add user to team
curl -X POST -H "Content-Type: application/json" \
  -d '{"userId": 2}' \
  http://admin:admin@localhost:3000/api/teams/1/members

# Set team role
curl -X PUT -H "Content-Type: application/json" \
  -d '{"role": "Admin"}' \
  http://admin:admin@localhost:3000/api/teams/1/members/2
```

### SSO Configuration
```yaml
# SAML Configuration
[auth.saml]
enabled = true
idp_metadata_url = https://idp.example.com/metadata
sp_entity_id = https://grafana.example.com
assertion_attribute_name = email
role_attribute_strict = true
role_attribute_name = role

# LDAP Configuration
[auth.ldap]
enabled = true
config_file = /etc/grafana/ldap.toml
allow_sign_up = true
```

### Audit Logging
```yaml
# Audit Log Configuration
[audit]
enabled = true
log_queries = true
log_events = "query, datasource, dashboard"
```

## Interview Questions

### Beginner Level
1. **What is Grafana?**
   - Grafana is an open-source visualization and monitoring platform that enables you to query, visualize, alert on, and understand your metrics

2. **What are the main features of Grafana?**
   - Multi-source data support, beautiful dashboards, built-in alerting, templating, annotations, and plugin system

3. **What types of data sources can Grafana connect to?**
   - Prometheus, InfluxDB, Elasticsearch, MySQL, PostgreSQL, Graphite, and many more

4. **What is a dashboard in Grafana?**
   - A dashboard is a collection of panels that visualize data from various sources

### Intermediate Level
1. **What are Grafana variables?**
   - Variables are template parameters that make dashboards dynamic and reusable

2. **How does Grafana alerting work?**
   - Grafana alerting uses rules defined on panels to trigger notifications when conditions are met

3. **What are the different types of panels in Grafana?**
   - Time series, stat, gauge, table, heatmap, pie chart, logs, and more

4. **How do you provision Grafana configurations?**
   - Grafana can be provisioned using configuration files for data sources, dashboards, and folders

### Advanced Level
1. **How does Grafana handle high availability?**
   - Grafana can be deployed in a cluster with shared database and file storage for high availability

2. **What is the difference between Grafana Cloud and self-hosted Grafana?**
   - Grafana Cloud is a managed service with additional features, while self-hosted Grafana gives you full control

3. **How do you secure Grafana?**
   - Use authentication, authorization, SSL/TLS, network security, and audit logging

4. **How do you optimize Grafana performance?**
   - Optimize queries, use caching, limit dashboard complexity, and scale horizontally

## Best Practices

### Dashboard Design
- **Keep it Simple**: Avoid cluttered dashboards with too many panels
- **Use Consistent Naming**: Use consistent naming conventions for dashboards and panels
- **Choose Right Visualizations**: Select appropriate visualization types for your data
- **Use Variables**: Use template variables to make dashboards dynamic
- **Organize in Folders**: Organize dashboards in logical folders

### Alert Configuration
- **Set Appropriate Thresholds**: Set realistic alert thresholds to avoid alert fatigue
- **Use Multiple Channels**: Configure multiple notification channels
- **Test Alert Rules**: Test alert rules before deploying to production
- **Document Alert Rules**: Document alert rules and their purpose
- **Review Regularly**: Regularly review and update alert rules

### Performance Optimization
- **Optimize Queries**: Write efficient queries to minimize load on data sources
- **Use Caching**: Enable caching for frequently accessed data
- **Limit Time Range**: Limit dashboard time ranges to improve performance
- **Use Refresh Intervals**: Set appropriate refresh intervals
- **Monitor Grafana**: Monitor Grafana performance itself

## Troubleshooting

### Common Issues
```bash
# Check Grafana status
sudo systemctl status grafana-server

# Check Grafana logs
sudo journalctl -u grafana-server -f

# Check configuration
sudo grafana-server -config /etc/grafana/grafana.ini -homepath /usr/share/grafana

# Test data source connection
curl -u admin:admin http://localhost:3000/api/datasources/1/health

# Check API access
curl -u admin:admin http://localhost:3000/api/health
```

### Debugging Tips
- **Check Logs**: Always check Grafana logs for error messages
- **Test Queries**: Test queries directly in data source query editors
- **Check Permissions**: Verify user permissions and data source access
- **Monitor Resources**: Monitor system resources (CPU, memory, disk)
- **Check Network**: Verify network connectivity to data sources

## Resources

### Official Documentation
- [Grafana Documentation](https://grafana.com/docs/)
- [Grafana Tutorials](https://grafana.com/tutorials/)
- [Grafana Downloads](https://grafana.com/grafana/download)

### Learning Resources
- [Grafana Academy](https://grafana.com/academy/)
- [Grafana Blog](https://grafana.com/blog/)
- [Grafana Community](https://community.grafana.com/)

### Community
- [Grafana Forums](https://community.grafana.com/)
- [Grafana GitHub](https://github.com/grafana/grafana)
- [Grafana Stack Overflow](https://stackoverflow.com/questions/tagged/grafana)